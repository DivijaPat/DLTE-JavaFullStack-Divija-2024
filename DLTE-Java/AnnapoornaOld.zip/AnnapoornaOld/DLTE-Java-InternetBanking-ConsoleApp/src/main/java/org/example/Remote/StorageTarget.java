package org.example.Remote;

public interface StorageTarget {
    UserDetailsRepository getUserDetailsRepository();
}
