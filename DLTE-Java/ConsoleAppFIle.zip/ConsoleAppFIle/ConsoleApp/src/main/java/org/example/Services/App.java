package org.example.Services;

import org.example.Entity.Account;
import org.example.Exceptions.InsufficientFundsException;
import org.example.Exceptions.InvalidCredentialsException;
import org.example.Exceptions.ReceiverNotFoundException;
import org.example.Middleware.FileStorageTarget;
import org.example.Middleware.UserDetailsFileRepository;
import org.example.Remote.StorageTarget;
//import org.slf4j.Logger;

import javax.security.auth.login.AccountNotFoundException;
import java.io.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Logger;


import static java.lang.System.exit;

/**
 * Hello world!
 *
 */
public class App {
    private static Account account;
    private static Logger logger = Logger.getLogger(UserDetailsFileRepository.class.getName());

    private static StorageTarget storageTarget;
    private static AccountServices services;
    private static Scanner scanner = new Scanner(System.in);
    private static ResourceBundle resourceBundle = ResourceBundle.getBundle("application");

    List<Account> accountList=new ArrayList<>();
    public static void main(String[] args) throws InvalidCredentialsException, SQLException {

        int option;
        boolean status=false;
        String username, password;
        storageTarget = new FileStorageTarget();
        services = new AccountServices(storageTarget);

//
//        try {
            System.out.println("Enter your username: ");
            username = scanner.nextLine();
            System.out.println("Enter your password: ");
             password = scanner.nextLine();
        try {
            status = services.authenticate(username, password);
        } catch (InvalidCredentialsException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        if(status)
               System.out.println("successful");
            while (status) {
                System.out.println("Authentication successful!");
                System.out.println("\nMenu:");
                System.out.println(resourceBundle.getString("app.menu"));
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        System.out.println("Enter receiver's username: ");
                        String receiverUsername = scanner.nextLine();
                        System.out.println("Enter amount to transfer: ");
                        double amount = scanner.nextDouble();
                        scanner.nextLine();
                        System.out.println("Enter your username: ");
                        String username1 = scanner.nextLine();
                        System.out.println("Enter your password: ");
                        String password1 = scanner.nextLine();


                        boolean currentUser1 = false;
                        try {
                            currentUser1 = services.authenticate(username, password);
                        } catch (InvalidCredentialsException ex) {
                            ex.printStackTrace();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                        if(currentUser1) {
                            System.out.println("Authentication successful!");
                            try {
                                services.transferFunds(username, receiverUsername, amount);
                                System.out.println("Transaction successful!");
                            } catch (InsufficientFundsException | ReceiverNotFoundException | IOException e) {
                                System.out.println(e.getMessage());
                            } catch (AccountNotFoundException e) {
                                e.printStackTrace();
                            }

                        }
                        break;
                    case 2:
                        System.out.println(resourceBundle.getString("under.progress"));
                        break;
                    case 3:
                        System.out.println(resourceBundle.getString("under.progress"));
                        break;
                    case 4:
                        System.out.println(resourceBundle.getString("under.progress"));
                        break;
                    case 5:
                        System.out.println(resourceBundle.getString("under.progress"));
                        break;
                    case 6:
                        System.out.println("Exiting...");
                        status = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
//        } catch (InvalidCredentialsException e) {
//            System.out.println(resourceBundle.getString("wrong.password"));
//        }
    }
}



