package org.example.services;
import org.example.entity.Account;
import org.example.entity.Transaction;
import org.example.exceptions.InsufficientFundsException;
import org.example.exceptions.InvalidCredentialsException;
import org.example.exceptions.ReceiverNotFoundException;
import org.example.remotes.StorageTarget;
import org.example.remotes.UserDetailsRepository;

import javax.security.auth.login.AccountNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.List;
import java.util.ResourceBundle;

public class TransactionServices {
    UserDetailsRepository userDetailsRepository;
    StorageTarget storageTarget;
    private ResourceBundle resourceBundle = ResourceBundle.getBundle("application");

    public TransactionServices(StorageTarget storageTarget) {
        userDetailsRepository = storageTarget.getUserDetailsRepository();
    }

    Account getAccountByUsername(String username) throws AccountNotFoundException {
        try {
            return userDetailsRepository.getAccountByUsername(username);
        } catch (AccountNotFoundException accountNotFoundException) {
            throw accountNotFoundException;
        }
    }

    public List<Account> getAllAccounts()
    {
        return userDetailsRepository.getAllAccounts();
    }

    void transferFunds(String senderUsername, String receiverUsername, double amount) throws InsufficientFundsException, ReceiverNotFoundException, IOException, AccountNotFoundException {
        try {
            userDetailsRepository.transferFunds(senderUsername, receiverUsername, amount);
        } catch (InsufficientFundsException insufficientFundsException) {
            throw insufficientFundsException;
        } catch (ReceiverNotFoundException receiverNotFoundException) {
            throw receiverNotFoundException;
        } catch (IOException iOException) {
            throw iOException;
        } catch (AccountNotFoundException accountNotFoundException) {
            throw accountNotFoundException;
        }
    }

    void updateAccountBalance(Account account) throws IOException, AccountNotFoundException {
        try {
            userDetailsRepository.updateAccountBalance(account);
        } catch (IOException ioException) {
            throw ioException;
        } catch (AccountNotFoundException accountNotFoundException) {
            throw accountNotFoundException;
        }
    }

    public Account authenticate(String username, String password) throws InvalidCredentialsException, SQLException {
        try {
            return userDetailsRepository.authenticate(username, password);
        } catch (InvalidCredentialsException invalidCredentialsException) {
            throw invalidCredentialsException;
        } catch (SQLException sqlException) {
            throw sqlException;
        }

    }



}

