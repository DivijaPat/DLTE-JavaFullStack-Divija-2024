package org.example.remotes;

import org.example.entity.Account;
import org.example.entity.Transaction;
import org.example.exceptions.InsufficientFundsException;
import org.example.exceptions.InvalidCredentialsException;
import org.example.exceptions.ReceiverNotFoundException;

import javax.security.auth.login.AccountNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public interface UserDetailsRepository {
    List<Account> getAllAccounts();
    Account getAccountByUsername(String username) throws AccountNotFoundException;
    void transferFunds(String senderUsername, String receiverUsername, double amount) throws InsufficientFundsException, ReceiverNotFoundException, IOException, AccountNotFoundException;
    void updateAccountBalance(Account account) throws IOException, AccountNotFoundException;
    Account authenticate(String username, String password) throws InvalidCredentialsException, SQLException;
}
//String sender, String receiverUsername, double amount

