package console.frontend;
import backend.database.DatabaseRepositoryImplementation;
import backend.pojo.Employee;
import backend.pojo.InputEmployeeDetails;
import console.pojo.Employee1;
import console.pojo.EmployeeAddress1;
import console.pojo.EmployeeBasicDetails1;
import exception.EmployeeNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;


public class ConsoleApp {

    private static ResourceBundle resourceBundle = ResourceBundle.getBundle("application");

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            InputEmployeeDetails inputEmployeeDetails = new backend.database.DatabaseRepositoryImplementation();
            Logger logger = LoggerFactory.getLogger(ConsoleApp.class);
            try {
                List<Employee> employees = new ArrayList<>();
                while (true) {
                    boolean validate = false;
                    System.out.println(resourceBundle.getString("menu.display"));
                    System.out.println(resourceBundle.getString("enter.choice"));
                    int choice = 0;
                    do {
                        try {
                            choice = scanner.nextInt();
                            validate = true;
                        }
                        // checking for input format
                        catch (InputMismatchException inputMismatchException) {
                            System.out.println(resourceBundle.getString("Enter.valid"));
                            scanner.nextLine();
                        }
                    } while (!validate);
                    switch (choice) {

                        case 1://reading employee details
                          readAll(scanner);
                            break;
                        case 2://display employee based on employee id
                            displayBasedOnId(scanner);
                            break;

                        case 3://displaying all employees
                            displayAll(scanner);
                            break;
                        case 4://display based on pincode
                           displayBasedOnPincode(scanner);
                            break;
                        case 5:
                            System.exit(0);
                    }
                }
            } finally {
                // Close connections
                inputEmployeeDetails.closeConnections();
                scanner.close();
            }
        }
    }

    public static void readAll(Scanner scanner){
        Employee1 employeeConsole;
        EmployeeAddress1 employeePermanentAddressConsole;
        EmployeeAddress1 employeeTemporaryAddressConsole;
        EmployeeBasicDetails1 employeeBasicDetailsConsole;
        Translataion translataion = new Translataion();
        Validation validation = new Validation();

        InputEmployeeDetails inputEmployeeDetails = new backend.database.DatabaseRepositoryImplementation();
        do {

            System.out.println(resourceBundle.getString("enter.details"));
            System.out.print(resourceBundle.getString("enter.name"));
            scanner.next();
            String name = scanner.next();

            System.out.print(resourceBundle.getString("enter.id"));
            String id = scanner.next();

            System.out.print(resourceBundle.getString("enter.emailId"));
            String email = scanner.next();

            if (!validation.isValidEmail(email)) {
                System.out.println(resourceBundle.getString("invalid.email"));
                break;
            }

            System.out.print(resourceBundle.getString("enter.phone"));
            long phoneNumber = scanner.nextLong();

            if (!validation.isValidPhoneNumber(phoneNumber)) {
                System.out.println(resourceBundle.getString("invalid.Phone"));
                break;
            }

            System.out.println(resourceBundle.getString("enter.permanentAddress"));
            System.out.print(resourceBundle.getString("enter.street"));
            String permanentAddress = scanner.next();

            System.out.print(resourceBundle.getString("enter.HouseName"));
            String permanentHouseNumber = scanner.next();

            System.out.print(resourceBundle.getString("enter.city"));
            String permanentCity = scanner.next();

            System.out.print(resourceBundle.getString("enter.state"));
            String permanentState = scanner.next();

            System.out.print(resourceBundle.getString("enter.pincode"));
            int permanentPinCode =scanner.nextInt();

            if (!validation.isValidPin(permanentPinCode)) {
                System.out.println(resourceBundle.getString("invalid.Pin"));
                break;
            }

            System.out.println(resourceBundle.getString("enter.temporaryaddress"));
            System.out.print(resourceBundle.getString("enter.street"));
            String temporaryAddress = scanner.next();

            System.out.print(resourceBundle.getString("enter.HouseName"));
            String temporaryHouseNumber = scanner.next();

            System.out.print(resourceBundle.getString("enter.city"));
            String temporaryCity = scanner.next();

            System.out.print(resourceBundle.getString("enter.state"));
            String temporaryState = scanner.next();

            System.out.print(resourceBundle.getString("enter.pincode"));
            int temporaryPinCode = scanner.nextInt();

            if (!validation.isValidPin(temporaryPinCode)) {
                System.out.println(resourceBundle.getString("invalid.Pin"));
                break;
            }
            employeeBasicDetailsConsole = new EmployeeBasicDetails1(name, id, email, phoneNumber);
            employeePermanentAddressConsole = new EmployeeAddress1(permanentAddress, permanentHouseNumber, permanentState, permanentCity, permanentPinCode);
            employeeTemporaryAddressConsole = new EmployeeAddress1(temporaryAddress, temporaryHouseNumber, temporaryState, temporaryCity, temporaryPinCode);
            employeeConsole = new Employee1(employeeBasicDetailsConsole, employeePermanentAddressConsole, employeeTemporaryAddressConsole);
            Employee employee;
            employee = translataion.translateEmployee(employeeConsole);

            List<Employee> employeeInfo = new ArrayList<>();
            employeeInfo.add(employee);
            inputEmployeeDetails.create(employeeInfo);

            System.out.print(resourceBundle.getString("add.more"));


        } while (scanner.next().equalsIgnoreCase(resourceBundle.getString("say.yes")));
    }



    public static void displayBasedOnId(Scanner scanner){
        Logger logger = LoggerFactory.getLogger(ConsoleApp.class);
        Employee1 employeeConsoleId;
        Translataion translataion = new Translataion();
        InputEmployeeDetails inputEmployeeDetails = new backend.database.DatabaseRepositoryImplementation();
        System.out.println(resourceBundle.getString("enter.id"));
        String employeeId = scanner.next();
        try {
            Employee employee = inputEmployeeDetails.displayBasedOnEmployeeId(employeeId);
            employeeConsoleId = translataion.translate(employee);
            System.out.println(employeeConsoleId.displayEmployeeDetails());
        } catch (EmployeeNotFoundException e) {
            System.out.println(e.getMessage());
            logger.warn(e.getMessage());
        }
    }

    public static void displayAll(Scanner scanner){
        Employee1 employeeConsole;
        Logger logger = LoggerFactory.getLogger(ConsoleApp.class);
        Translataion translataion = new Translataion();
        InputEmployeeDetails inputEmployeeDetails = new backend.database.DatabaseRepositoryImplementation();
        List<Employee> allEmployees = inputEmployeeDetails.read();
        if (!allEmployees.isEmpty()) {
            for (Employee emp : allEmployees) {
                employeeConsole = translataion.translate(emp);
                System.out.println(employeeConsole.displayEmployeeDetails() + "\n");

            }
        } else {
            System.out.println(resourceBundle.getString("employee.not.found"));
            logger.warn(resourceBundle.getString("employee.not.found"));
        }
    }

    public static void displayBasedOnPincode(Scanner scanner){
        InputEmployeeDetails inputEmployeeDetails = new backend.database.DatabaseRepositoryImplementation();
        Translataion translataion = new Translataion();
        Logger logger = LoggerFactory.getLogger(ConsoleApp.class);
        Employee1 employeeConsolePin;
        System.out.println(resourceBundle.getString("enter.pincode"));
        int pinCode = scanner.nextInt();
        try {
            Employee employee = inputEmployeeDetails.displayBasedOnPinCode(pinCode);
            employeeConsolePin = translataion.translate(employee);
            System.out.println(employeeConsolePin.displayEmployeeDetails());
        } catch (EmployeeNotFoundException e) {
            System.out.println(e.getMessage());
            logger.warn(e.getMessage());
        }
    }

        }