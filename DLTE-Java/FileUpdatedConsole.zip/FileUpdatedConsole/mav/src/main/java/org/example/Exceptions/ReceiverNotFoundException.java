package org.example.Exceptions;
public class ReceiverNotFoundException extends Exception {
    public ReceiverNotFoundException(String message) {
        super(message);
    }
}
