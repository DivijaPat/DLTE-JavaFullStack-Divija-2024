package basics.service.remotes;

import basics.service.middleware.UserFileRepository;

public interface StorageTarget {
 UserRepository getUserRepository();
}
